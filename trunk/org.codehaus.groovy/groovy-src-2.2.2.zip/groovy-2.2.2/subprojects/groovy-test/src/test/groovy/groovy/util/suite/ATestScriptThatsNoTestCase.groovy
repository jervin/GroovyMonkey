// used for testing ScriptTestCaseAdapter usage with AllTestSuite
assert true